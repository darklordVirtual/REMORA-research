"""AROMER world model."""
