# Author: Stian Skogbrott
# SPDX-License-Identifier: BUSL-1.1
"""REMORA Policy Enforcement Point (PEP) package.

ARCHITECTURAL BOUNDARY (REM-013):
  PDP = remora.policy.decision_engine.RemoraDecisionEngine (produces signed tokens)
  PEP = remora.enforcement.gate.EnforcementGate (verifies tokens, blocks execution)

The PEP must NEVER call the PDP directly. It receives a signed PolicyDecisionToken
from the API or orchestrator layer and verifies the HMAC signature before
allowing action execution. Without a valid signed token (in strict mode),
the PEP fails closed.

Deployment pattern:
    1. API/orchestrator calls PDP: report = engine.decide(obs)
    2. API/orchestrator issues token: token = PolicyDecisionToken.issue(
           action=report.action.value,
           observation_hash=_hash_observation(obs),
           request_id=req_id,
           issued_at=utc_now_str,
       )
    3. Token passed to PEP layer (may cross process/network boundary)
    4. PEP verifies and enforces: gate.enforce(token, execute_fn)

INTEGRATION STATUS: this package is a library plus its test suite. The
PDP/PEP token flow is wired into the execution API (servers/execution_api.py,
/v1/execution/*); see capability_register CAP-003. Outside that API path the
deployment pattern above is prescriptive, not a description of current
wiring — remora/adapters/action_gate.py calls the PDP directly. This is
consistent with deployment_status=SHADOW_ONLY (ARCHITECTURE.md §10); do not
cite this package as evidence of integrated, unbypassable enforcement.

ExecutionLease + GovernedToolDispatcher (lease.py) extend the token pattern
with the full REM-024 binding set (tenant, actor, tool, canonical args hash,
environment, policy bundle, nonce, expiry) and a tool proxy that refuses
execution without a valid lease. Library-level; REM-024 remains open until it
fronts real tool credentials in deployment.

See docs/assurance/remediation_register.yaml REM-013 and REM-024.
"""
from remora.enforcement.gate import EnforcementGate, EnforcementResult
from remora.enforcement.lease import (
    DispatchResult,
    ExecutionLease,
    GovernedToolDispatcher,
    LeaseRefused,
    LeaseVerificationResult,
    NonceLedger,
)
from remora.enforcement.token import (
    PolicyDecisionToken,
    TokenVerificationResult,
    _hash_observation,
)

__all__ = [
    "DispatchResult",
    "EnforcementGate",
    "EnforcementResult",
    "ExecutionLease",
    "GovernedToolDispatcher",
    "LeaseRefused",
    "LeaseVerificationResult",
    "NonceLedger",
    "PolicyDecisionToken",
    "TokenVerificationResult",
    "_hash_observation",
]
